import { Button } from "@/components/ui/button";
import { BookOpen, Gamepad2, Headphones, Palette } from "lucide-react";

const activities = [
  {
    icon: BookOpen,
    title: "Cozy Stories",
    desc: "Calm, illustrated tales with characters who think and feel like you do.",
    cta: "Read a story",
    bg: "bg-accent/50",
    iconBg: "bg-accent",
  },
  {
    icon: Gamepad2,
    title: "Brain Games",
    desc: "Playful puzzles built for different thinking styles. No stress, just fun.",
    cta: "Play now",
    bg: "bg-sunshine/50",
    iconBg: "bg-sunshine",
  },
  {
    icon: Headphones,
    title: "Quiet Sounds",
    desc: "Soft music, nature sounds, and breathing buddies to help you feel calm.",
    cta: "Listen",
    bg: "bg-secondary/60",
    iconBg: "bg-secondary",
  },
  {
    icon: Palette,
    title: "Make & Create",
    desc: "Drawing prompts, sensory crafts, and big-idea projects to try at home.",
    cta: "Get crafty",
    bg: "bg-lavender/60",
    iconBg: "bg-lavender",
  },
];

const Explore = () => {
  return (
    <section id="explore" className="py-24 bg-gradient-warm relative overflow-hidden">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-block px-4 py-1.5 rounded-full bg-card/70 text-sm font-bold text-accent-foreground mb-4 shadow-soft">
            🎈 Pick your adventure
          </span>
          <h2 className="font-[Fredoka] text-4xl md:text-5xl font-bold text-foreground mb-4">
            Things to explore today
          </h2>
          <p className="text-lg text-muted-foreground">
            Choose what feels right. There's no wrong way to play here.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {activities.map((a) => {
            const Icon = a.icon;
            return (
              <div
                key={a.title}
                className={`${a.bg} rounded-[2rem] p-7 flex flex-col items-start gap-4 shadow-soft hover:shadow-pop transition-bounce hover:-translate-y-2 backdrop-blur-sm`}
              >
                <div className={`${a.iconBg} h-14 w-14 rounded-2xl flex items-center justify-center shadow-soft`}>
                  <Icon className="h-7 w-7 text-foreground" strokeWidth={2.2} />
                </div>
                <h3 className="font-[Fredoka] text-2xl font-bold text-foreground">{a.title}</h3>
                <p className="text-foreground/75 flex-1">{a.desc}</p>
                <Button variant="outline" size="sm" className="bg-card/80">{a.cta} →</Button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Explore;
