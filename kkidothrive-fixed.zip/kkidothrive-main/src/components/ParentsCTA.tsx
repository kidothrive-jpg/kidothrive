import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import heart from "@/assets/heart.png";

const features = [
  "Sensory-friendly design with calm colors and gentle motion",
  "Activities curated by educators and neurodivergent adults",
  "No ads, no trackers, no pressure — ever",
  "Tools to help you talk about big feelings together",
];

const ParentsCTA = () => {
  return (
    <section id="parents" className="py-24">
      <div className="container">
        <div className="grid lg:grid-cols-5 gap-10 items-center bg-card rounded-[3rem] p-8 md:p-14 shadow-soft border border-border/50 relative overflow-hidden">
          <div className="absolute -top-10 -right-10 w-48 h-48 bg-accent/30 rounded-full blur-3xl" />
          <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-secondary/40 rounded-full blur-3xl" />

          <div className="lg:col-span-2 relative flex justify-center">
            <img src={heart} alt="" width={768} height={768} className="w-64 md:w-80 animate-float" loading="lazy" />
          </div>

          <div className="lg:col-span-3 relative space-y-6">
            <span className="inline-block px-4 py-1.5 rounded-full bg-primary/20 text-primary-foreground text-sm font-bold">
              For parents & caregivers
            </span>
            <h2 className="font-[Fredoka] text-4xl md:text-5xl font-bold text-foreground leading-tight">
              Made with love, backed by experts
            </h2>
            <p className="text-lg text-muted-foreground">
              Bright Minds is built alongside therapists, teachers, and the neurodivergent
              community — so you can feel good about every minute your child spends here.
            </p>
            <ul className="space-y-3">
              {features.map((f) => (
                <li key={f} className="flex items-start gap-3">
                  <span className="mt-0.5 h-6 w-6 rounded-full bg-primary/30 flex items-center justify-center flex-shrink-0">
                    <Check className="h-3.5 w-3.5 text-primary-foreground" strokeWidth={3} />
                  </span>
                  <span className="text-foreground/85">{f}</span>
                </li>
              ))}
            </ul>
            <div className="flex flex-wrap gap-3 pt-2">
              <Button variant="default" size="lg">Get the parent guide</Button>
              <Button variant="ghost" size="lg">Read our story</Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ParentsCTA;
