import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";

interface CompletionScreenProps {
  title: string;
  message: string;
  emoji?: string;
  onRepeat?: () => void;
  repeatLabel?: string;
  exploreLabel?: string;
}

const CompletionScreen = ({
  title,
  message,
  emoji = "🌟",
  onRepeat,
  repeatLabel = "Do it again",
  exploreLabel = "Explore something else",
}: CompletionScreenProps) => {
  return (
    <div className="max-w-xl mx-auto text-center animate-fade-up">
      <div className="rounded-[2.5rem] bg-gradient-warm p-10 md:p-14 shadow-soft">
        <div className="text-6xl md:text-7xl mb-4 animate-wiggle inline-block" aria-hidden>
          {emoji}
        </div>
        <h2 className="font-[Fredoka] text-3xl md:text-4xl font-bold text-foreground mb-3">
          {title}
        </h2>
        <p className="text-lg text-foreground/80 mb-8">{message}</p>

        <div className="flex flex-wrap gap-3 justify-center">
          {onRepeat && (
            <Button variant="hero" size="lg" onClick={onRepeat}>
              <Sparkles className="h-4 w-4" /> {repeatLabel}
            </Button>
          )}
          <Link to="/explore">
            <Button variant="outline" size="lg" className="bg-card/80">
              {exploreLabel} →
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CompletionScreen;
