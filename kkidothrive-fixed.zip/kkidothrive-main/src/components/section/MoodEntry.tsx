interface MoodOption<T extends string> {
  id: T;
  label: string;
  emoji: string;
  bg: string;
}

interface MoodEntryProps<T extends string> {
  question: string;
  hint?: string;
  options: MoodOption<T>[];
  value: T | null;
  onChange: (v: T) => void;
}

function MoodEntry<T extends string>({
  question,
  hint,
  options,
  value,
  onChange,
}: MoodEntryProps<T>) {
  return (
    <div className="text-center max-w-2xl mx-auto">
      <h2 className="font-[Fredoka] text-2xl md:text-3xl font-bold text-foreground">
        {question}
      </h2>
      {hint && <p className="text-muted-foreground mt-1">{hint}</p>}

      <div className="mt-6 flex flex-wrap justify-center gap-3">
        {options.map((m) => {
          const active = value === m.id;
          return (
            <button
              key={m.id}
              onClick={() => onChange(m.id)}
              aria-pressed={active}
              className={`px-5 py-3 rounded-full font-semibold text-sm shadow-soft transition-bounce hover:scale-105 flex items-center gap-2 ${m.bg} ${
                active ? "ring-4 ring-foreground/15 scale-105" : "opacity-80 hover:opacity-100"
              }`}
            >
              <span className="text-lg" aria-hidden>{m.emoji}</span>
              <span className="text-foreground">{m.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default MoodEntry;
