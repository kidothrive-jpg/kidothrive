import { ReactNode } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Users } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";

interface SectionLayoutProps {
  title: string;
  emoji: string;
  tagline?: string;
  bgClass?: string;
  children: ReactNode;
}

const SectionLayout = ({
  title,
  emoji,
  tagline,
  bgClass = "bg-gradient-sky",
  children,
}: SectionLayoutProps) => {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <main className="flex-1">
        <section className={`relative overflow-hidden ${bgClass}`}>
          <div className="absolute -top-16 -left-16 h-56 w-56 bg-accent/30 animate-blob blur-2xl" />
          <div className="absolute top-10 -right-16 h-64 w-64 bg-sunshine/30 animate-blob blur-2xl" style={{ animationDelay: "2s" }} />

          <div className="container relative py-10 md:py-14">
            <div className="flex items-center justify-between mb-6">
              <Link to="/explore">
                <Button variant="outline" size="sm" className="bg-card/80">
                  <ArrowLeft className="h-4 w-4" /> Back to Explore
                </Button>
              </Link>
              <Link to="/#parents" className="hidden sm:block">
                <Button variant="ghost" size="sm">
                  <Users className="h-4 w-4" /> For grown-ups
                </Button>
              </Link>
            </div>

            <div className="text-center max-w-2xl mx-auto animate-fade-up">
              <div className="text-5xl md:text-6xl mb-3" aria-hidden>{emoji}</div>
              <h1 className="font-[Fredoka] text-3xl md:text-5xl font-bold text-foreground">
                {title}
              </h1>
              {tagline && (
                <p className="mt-3 text-base md:text-lg text-muted-foreground">{tagline}</p>
              )}
            </div>
          </div>
        </section>

        <section className="py-10 md:py-14">
          <div className="container">{children}</div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default SectionLayout;
