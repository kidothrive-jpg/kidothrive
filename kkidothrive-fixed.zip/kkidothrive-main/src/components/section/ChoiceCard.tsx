import { ReactNode } from "react";
import { LucideIcon } from "lucide-react";

interface ChoiceCardProps {
  icon?: LucideIcon;
  emoji?: string;
  title: string;
  desc?: string;
  bg?: string;
  iconBg?: string;
  active?: boolean;
  onClick?: () => void;
  children?: ReactNode;
}

const ChoiceCard = ({
  icon: Icon,
  emoji,
  title,
  desc,
  bg = "bg-card",
  iconBg = "bg-accent",
  active,
  onClick,
  children,
}: ChoiceCardProps) => {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={`${bg} text-left rounded-[2rem] p-6 md:p-7 flex flex-col items-start gap-4 shadow-soft hover:shadow-pop transition-bounce hover:-translate-y-2 backdrop-blur-sm w-full ${
        active ? "ring-4 ring-foreground/15 scale-[1.02]" : ""
      }`}
    >
      <div className="flex items-center gap-3">
        <div className={`${iconBg} h-14 w-14 rounded-2xl flex items-center justify-center shadow-soft`}>
          {Icon ? <Icon className="h-7 w-7 text-foreground" strokeWidth={2.2} /> : null}
        </div>
        {emoji && <span className="text-3xl" aria-hidden>{emoji}</span>}
      </div>
      <h3 className="font-[Fredoka] text-xl md:text-2xl font-bold text-foreground">{title}</h3>
      {desc && <p className="text-foreground/75">{desc}</p>}
      {children}
    </button>
  );
};

export default ChoiceCard;
