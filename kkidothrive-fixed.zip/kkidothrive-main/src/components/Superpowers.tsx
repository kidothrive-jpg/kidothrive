import brain from "@/assets/superpower-brain.png";

const powers = [
  {
    emoji: "🧩",
    title: "Pattern Detectives",
    desc: "Spotting things others miss — puzzles, codes, and tiny details light up your brain.",
    color: "bg-secondary",
    rotate: "-rotate-2",
  },
  {
    emoji: "⚡",
    title: "Big Energy",
    desc: "Curious, fast, and full of ideas. Your brain runs on rocket fuel — and that's amazing.",
    color: "bg-sunshine",
    rotate: "rotate-2",
  },
  {
    emoji: "📚",
    title: "Word Wizards",
    desc: "Reading can feel tricky, but your imagination, listening, and storytelling are pure magic.",
    color: "bg-accent",
    rotate: "-rotate-1",
  },
  {
    emoji: "🎨",
    title: "Creative Thinkers",
    desc: "You see the world in colors and connections nobody else can — and we love that.",
    color: "bg-lavender",
    rotate: "rotate-1",
  },
  {
    emoji: "🦋",
    title: "Deep Feelers",
    desc: "Your big feelings are a gift. They make you kind, thoughtful, and beautifully you.",
    color: "bg-primary/40",
    rotate: "-rotate-2",
  },
  {
    emoji: "🔭",
    title: "Focus Fans",
    desc: "When something clicks, you can dive in for hours. That's called 'flow' — and it's a superpower.",
    color: "bg-secondary",
    rotate: "rotate-2",
  },
];

const Superpowers = () => {
  return (
    <section id="superpowers" className="relative py-24 overflow-hidden">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <img src={brain} alt="" width={768} height={768} className="w-32 h-32 mx-auto mb-6 animate-float" loading="lazy" />
          <h2 className="font-[Fredoka] text-4xl md:text-5xl font-bold text-foreground mb-4">
            Your brain is the coolest brain
          </h2>
          <p className="text-lg text-muted-foreground">
            Some kids are great at running. Some at singing. And some have brains that work in
            wonderfully different ways. Here are a few superpowers we celebrate:
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {powers.map((p, i) => (
            <article
              key={p.title}
              className={`group ${p.color} rounded-[2rem] p-8 shadow-soft hover:shadow-pop transition-bounce hover:-translate-y-2 ${p.rotate} hover:rotate-0`}
              style={{ animationDelay: `${i * 100}ms` }}
            >
              <div className="text-5xl mb-4 group-hover:scale-125 transition-bounce inline-block">
                {p.emoji}
              </div>
              <h3 className="font-[Fredoka] text-2xl font-bold text-foreground mb-2">{p.title}</h3>
              <p className="text-foreground/75 leading-relaxed">{p.desc}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Superpowers;
