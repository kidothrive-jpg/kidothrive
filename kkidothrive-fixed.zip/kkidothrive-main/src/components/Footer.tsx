import { Link } from "react-router-dom";
import logo from "@/assets/kidothrive-wordmark.jpg";

const Footer = () => {
  return (
    <footer className="bg-gradient-sky border-t border-border/50">
      <div className="container py-14">
        <div className="grid md:grid-cols-4 gap-10 mb-10">
          <div className="md:col-span-2 space-y-4">
            <img
              src={logo}
              alt="KidoThrive — Empowering Every Child's Journey"
              width={1024}
              height={1024}
              className="h-16 w-auto object-contain -ml-2"
              loading="lazy"
            />
            <p className="text-muted-foreground max-w-md">
              A gentle, joyful corner of the internet for neurodivergent kids — and the grown-ups
              who love them. Empowering every child's journey, one bright moment at a time.
            </p>
          </div>
          <div>
            <h4 className="font-[Fredoka] font-bold mb-3 text-foreground">Explore</h4>
            <ul className="space-y-2 text-muted-foreground text-sm">
              <li><Link to="/stories" className="hover:text-primary transition-smooth">Stories</Link></li>
              <li><Link to="/games" className="hover:text-primary transition-smooth">Games</Link></li>
              <li><Link to="/calm" className="hover:text-primary transition-smooth">Calm Zone</Link></li>
              <li><Link to="/create" className="hover:text-primary transition-smooth">Crafts</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-[Fredoka] font-bold mb-3 text-foreground">Family</h4>
            <ul className="space-y-2 text-muted-foreground text-sm">
              <li><a href="/#parents" className="hover:text-primary transition-smooth">Parent Guide</a></li>
              <li><a href="/#parents" className="hover:text-primary transition-smooth">Resources</a></li>
              <li><a href="/#parents" className="hover:text-primary transition-smooth">Community</a></li>
              <li><a href="mailto:hello@kkidothrive.com" className="hover:text-primary transition-smooth">Contact</a></li>
            </ul>
          </div>
        </div>
        <div className="pt-8 border-t border-border/60 flex flex-col md:flex-row gap-3 items-center justify-between text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} KidoThrive. Made with 💛 for every kind of brain.</p>
          <p>Different is wonderful.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
