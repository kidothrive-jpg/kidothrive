import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Link, NavLink, useLocation } from "react-router-dom";
import { Menu, X } from "lucide-react";
import logo from "@/assets/kidothrive-wordmark.jpg";

const Navbar = () => {
  const { pathname } = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const onExplore = pathname.startsWith("/explore");

  const linkClass = (active: boolean) =>
    `relative transition-smooth ${
      active ? "text-primary" : "hover:text-primary"
    } after:content-[''] after:absolute after:-bottom-1 after:left-0 after:h-1 after:rounded-full after:bg-primary after:transition-all ${
      active ? "after:w-full" : "after:w-0 hover:after:w-full"
    }`;

  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-md bg-background/70 border-b border-border/50">
      <nav className="container flex h-20 items-center justify-between">
        <Link to="/" className="flex items-center group" aria-label="KidoThrive home">
          <img
            src={logo}
            alt="KidoThrive — Empowering Every Child's Journey"
            width={1024}
            height={1024}
            className="h-14 md:h-16 w-auto object-contain group-hover:scale-105 transition-bounce"
          />
        </Link>
        <div className="hidden md:flex items-center gap-8 text-sm font-semibold text-foreground/80">
          <a href="/#superpowers" className={linkClass(false)}>Superpowers</a>
          <NavLink to="/explore" className={linkClass(onExplore)}>Explore</NavLink>
          <a href="/#parents" className={linkClass(false)}>For Parents</a>
        </div>
        <div className="flex items-center gap-3">
          <Link to="/explore" className="hidden md:inline-flex">
            <Button variant="hero" size="default">Join the fun</Button>
          </Link>
          <button
            className="md:hidden p-2 rounded-lg hover:bg-accent/20 transition-smooth"
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </nav>

      {menuOpen && (
        <div className="md:hidden bg-background/95 backdrop-blur-md border-b border-border/50 px-6 pb-6 pt-2 flex flex-col gap-4">
          <a href="/#superpowers" className="text-sm font-semibold text-foreground/80 hover:text-primary transition-smooth py-2" onClick={() => setMenuOpen(false)}>Superpowers</a>
          <NavLink to="/explore" className="text-sm font-semibold text-foreground/80 hover:text-primary transition-smooth py-2" onClick={() => setMenuOpen(false)}>Explore</NavLink>
          <a href="/#parents" className="text-sm font-semibold text-foreground/80 hover:text-primary transition-smooth py-2" onClick={() => setMenuOpen(false)}>For Parents</a>
          <Link to="/explore" onClick={() => setMenuOpen(false)}>
            <Button variant="hero" size="default" className="w-full">Join the fun</Button>
          </Link>
        </div>
      )}
    </header>
  );
};

export default Navbar;
