import { Button } from "@/components/ui/button";
import { ArrowRight, Heart } from "lucide-react";
import { Link } from "react-router-dom";
import heroImg from "@/assets/hero-children.jpg";
import rainbow from "@/assets/rainbow.png";
import logoBadge from "@/assets/kidothrive-logo-full.jpg";

const Hero = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-sky">
      {/* Floating blobs */}
      <div className="absolute -top-20 -left-20 h-72 w-72 bg-accent/40 animate-blob blur-2xl" />
      <div className="absolute top-40 -right-20 h-80 w-80 bg-sunshine/40 animate-blob blur-2xl" style={{ animationDelay: "2s" }} />
      <div className="absolute bottom-0 left-1/3 h-64 w-64 bg-lavender/40 animate-blob blur-2xl" style={{ animationDelay: "4s" }} />

      <div className="container relative grid lg:grid-cols-2 gap-12 items-center py-16 lg:py-24">
        <div className="space-y-8 animate-fade-up">
          <div className="inline-flex items-center gap-2 rounded-full bg-card/70 backdrop-blur px-4 py-2 shadow-soft border border-border/50">
            <Heart className="h-4 w-4 text-accent fill-accent" />
            <span className="text-sm font-semibold text-foreground/80">A safe, sunny corner of the web</span>
          </div>

          <h1 className="font-[Fredoka] text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.05] text-foreground">
            Every brain is a{" "}
            <span className="relative inline-block">
              <span className="relative z-10">superpower</span>
              <span className="absolute bottom-2 left-0 right-0 h-4 bg-sunshine/70 -z-0 rounded-full" />
            </span>{" "}
            ✨
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground max-w-xl leading-relaxed">
            A joyful place built for kids who think, feel, and learn in their own wonderful way.
            Stories, games, and gentle tools — designed with neurodivergent minds in mind.
          </p>

          <div className="flex flex-wrap gap-4">
            <Link to="/explore">
              <Button variant="hero" size="xl">
                Start exploring <ArrowRight className="ml-1" />
              </Button>
            </Link>
            <Button variant="outline" size="xl" asChild>
              <a href="#parents">For grown‑ups</a>
            </Button>
          </div>

          <div className="flex items-center gap-6 pt-4">
            <div className="flex -space-x-2">
              {["bg-accent", "bg-sunshine", "bg-primary", "bg-lavender", "bg-secondary"].map((c, i) => (
                <div key={i} className={`h-10 w-10 rounded-full ${c} border-4 border-background`} />
              ))}
            </div>
            <p className="text-sm text-muted-foreground">
              <span className="font-bold text-foreground">12,000+</span> kids & families<br />
              feeling seen & celebrated
            </p>
          </div>
        </div>

        <div className="relative">
          <div className="absolute -top-10 -right-6 w-32 md:w-40 animate-float pointer-events-none">
            <img src={rainbow} alt="" width={768} height={768} className="w-full h-auto" />
          </div>
          <div className="relative rounded-[3rem] overflow-hidden shadow-pop border-8 border-card bg-card">
            <img
              src={heroImg}
              alt="Diverse, happy neurodivergent children playing and learning together in a sunny garden"
              width={1536}
              height={1152}
              className="w-full h-auto"
            />
          </div>
          <div className="absolute -bottom-8 -left-6 md:-left-10 h-28 w-28 md:h-36 md:w-36 rounded-full bg-card shadow-pop p-1.5 animate-wiggle overflow-hidden border-4 border-card">
            <img
              src={logoBadge}
              alt="KidoThrive logo"
              width={1024}
              height={1024}
              className="w-full h-full object-cover rounded-full"
              loading="lazy"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
