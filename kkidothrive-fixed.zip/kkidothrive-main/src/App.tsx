import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import ExplorePage from "./pages/Explore.tsx";
import Stories from "./pages/Stories.tsx";
import Games from "./pages/Games.tsx";
import Create from "./pages/Create.tsx";
import Calm from "./pages/Calm.tsx";
import Superpowers from "./pages/Superpowers.tsx";
import Sounds from "./pages/Sounds.tsx";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/explore" element={<ExplorePage />} />
          <Route path="/stories" element={<Stories />} />
          <Route path="/games" element={<Games />} />
          <Route path="/create" element={<Create />} />
          <Route path="/calm" element={<Calm />} />
          <Route path="/superpowers" element={<Superpowers />} />
          <Route path="/sounds" element={<Sounds />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
