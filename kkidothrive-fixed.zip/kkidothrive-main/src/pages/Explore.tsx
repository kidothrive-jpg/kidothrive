import { useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import {
  BookOpen,
  Gamepad2,
  Palette,
  Wind,
  Sparkles,
  Music,
  ShieldCheck,
  Users,
} from "lucide-react";

type Mood = "all" | "happy" | "calm" | "worried" | "energetic";

type Activity = {
  icon: typeof BookOpen;
  emoji: string;
  title: string;
  desc: string;
  bg: string;
  iconBg: string;
  cta: string;
  to: string;
  moods: Exclude<Mood, "all">[];
};

const activities: Activity[] = [
  {
    icon: BookOpen,
    emoji: "📖",
    title: "Stories",
    desc: "Calm stories made just for you.",
    bg: "bg-accent/40",
    iconBg: "bg-accent",
    cta: "Read a story",
    to: "/stories",
    moods: ["calm", "worried", "happy"],
  },
  {
    icon: Gamepad2,
    emoji: "🎮",
    title: "Games",
    desc: "Fun and gentle brain games.",
    bg: "bg-sunshine/50",
    iconBg: "bg-sunshine",
    cta: "Play now",
    to: "/games",
    moods: ["happy", "energetic"],
  },
  {
    icon: Palette,
    emoji: "🎨",
    title: "Create",
    desc: "Draw, imagine, and express yourself.",
    bg: "bg-lavender/50",
    iconBg: "bg-lavender",
    cta: "Start creating",
    to: "/create",
    moods: ["happy", "calm", "energetic"],
  },
  {
    icon: Wind,
    emoji: "🧘",
    title: "Calm Corner",
    desc: "Relax, breathe, and reset.",
    bg: "bg-secondary/60",
    iconBg: "bg-secondary",
    cta: "Take a breath",
    to: "/calm",
    moods: ["worried", "calm", "energetic"],
  },
  {
    icon: Sparkles,
    emoji: "🌟",
    title: "Superpowers",
    desc: "Discover what makes you amazing.",
    bg: "bg-primary/30",
    iconBg: "bg-primary",
    cta: "Find yours",
    to: "/superpowers",
    moods: ["happy", "calm", "worried"],
  },
  {
    icon: Music,
    emoji: "🎵",
    title: "Sounds & Music",
    desc: "Soothing sounds and happy tunes.",
    bg: "bg-accent/30",
    iconBg: "bg-accent",
    cta: "Listen",
    to: "/sounds",
    moods: ["calm", "worried", "happy"],
  },
];

const moods: { id: Mood; label: string; emoji: string; bg: string }[] = [
  { id: "happy", label: "Happy", emoji: "😊", bg: "bg-sunshine" },
  { id: "calm", label: "Calm", emoji: "😌", bg: "bg-secondary" },
  { id: "worried", label: "Worried", emoji: "😟", bg: "bg-lavender" },
  { id: "energetic", label: "Energetic", emoji: "⚡", bg: "bg-accent" },
];

const ExplorePage = () => {
  const [mood, setMood] = useState<Mood>("all");

  const filtered =
    mood === "all" ? activities : activities.filter((a) => a.moods.includes(mood));

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        {/* Header */}
        <section className="relative overflow-hidden bg-gradient-sky">
          <div className="absolute -top-16 -left-16 h-64 w-64 bg-accent/40 animate-blob blur-2xl" />
          <div className="absolute top-20 -right-16 h-72 w-72 bg-sunshine/40 animate-blob blur-2xl" style={{ animationDelay: "2s" }} />
          <div className="absolute bottom-0 left-1/2 h-56 w-56 bg-lavender/40 animate-blob blur-2xl" style={{ animationDelay: "4s" }} />

          <div className="container relative py-16 md:py-20 text-center">
            <div className="inline-flex items-center gap-2 rounded-full bg-card/80 backdrop-blur px-4 py-2 shadow-soft border border-border/50 mb-6 animate-fade-up">
              <ShieldCheck className="h-4 w-4 text-primary" />
              <span className="text-sm font-semibold text-foreground/80">A safe, sunny space 🌞</span>
            </div>

            <h1 className="font-[Fredoka] text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight max-w-3xl mx-auto animate-fade-up">
              What would you like to explore today? <span aria-hidden>🌈</span>
            </h1>
            <p className="mt-5 text-lg md:text-xl text-muted-foreground animate-fade-up">
              Choose what feels right for you 💛
            </p>

            <div className="mt-6 flex flex-wrap justify-center gap-3 text-xs font-semibold text-foreground/70">
              <span className="px-3 py-1.5 rounded-full bg-card/70 shadow-soft">✨ No ads</span>
              <span className="px-3 py-1.5 rounded-full bg-card/70 shadow-soft">🕊️ No pressure</span>
              <span className="px-3 py-1.5 rounded-full bg-card/70 shadow-soft">⏳ No time limits</span>
            </div>
          </div>
        </section>

        {/* Mood picker */}
        <section className="py-10 md:py-14">
          <div className="container">
            <div className="text-center max-w-xl mx-auto mb-6">
              <h2 className="font-[Fredoka] text-2xl md:text-3xl font-bold text-foreground">
                How are you feeling today?
              </h2>
              <p className="text-muted-foreground mt-1">Tap a feeling — we'll show what fits.</p>
            </div>

            <div className="flex flex-wrap justify-center gap-3">
              <button
                onClick={() => setMood("all")}
                aria-pressed={mood === "all"}
                className={`px-5 py-3 rounded-full font-semibold text-sm shadow-soft transition-bounce hover:scale-105 ${
                  mood === "all"
                    ? "bg-foreground text-background"
                    : "bg-card text-foreground/80 hover:bg-muted"
                }`}
              >
                🌈 Show me everything
              </button>
              {moods.map((m) => {
                const active = mood === m.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => setMood(m.id)}
                    aria-pressed={active}
                    className={`px-5 py-3 rounded-full font-semibold text-sm shadow-soft transition-bounce hover:scale-105 flex items-center gap-2 ${
                      active ? `${m.bg} ring-4 ring-foreground/10 scale-105` : `${m.bg}/60 hover:${m.bg}`
                    }`}
                  >
                    <span className="text-lg" aria-hidden>{m.emoji}</span>
                    <span className="text-foreground">{m.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </section>

        {/* Activity cards */}
        <section className="pb-20">
          <div className="container">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((a) => {
                const Icon = a.icon;
                return (
                  <Link
                    to={a.to}
                    key={a.title}
                    className={`${a.bg} rounded-[2rem] p-7 flex flex-col items-start gap-4 shadow-soft hover:shadow-pop transition-bounce hover:-translate-y-2 backdrop-blur-sm animate-fade-up`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`${a.iconBg} h-14 w-14 rounded-2xl flex items-center justify-center shadow-soft`}>
                        <Icon className="h-7 w-7 text-foreground" strokeWidth={2.2} />
                      </div>
                      <span className="text-3xl" aria-hidden>{a.emoji}</span>
                    </div>
                    <h3 className="font-[Fredoka] text-2xl font-bold text-foreground">{a.title}</h3>
                    <p className="text-foreground/75 flex-1">{a.desc}</p>
                    <span className="inline-flex items-center gap-1 text-sm font-semibold text-foreground/80 px-3 py-1.5 rounded-full bg-card/80 shadow-soft">
                      {a.cta} →
                    </span>
                  </Link>
                );
              })}
            </div>

            {filtered.length === 0 && (
              <p className="text-center text-muted-foreground mt-10">
                Nothing matches that feeling yet — try another mood 💫
              </p>
            )}
          </div>
        </section>

        {/* Parent toggle */}
        <section className="pb-20">
          <div className="container">
            <div className="rounded-[2rem] bg-gradient-warm p-8 md:p-10 shadow-soft flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="h-14 w-14 rounded-2xl bg-card flex items-center justify-center shadow-soft">
                  <Users className="h-7 w-7 text-foreground" />
                </div>
                <div>
                  <h3 className="font-[Fredoka] text-xl md:text-2xl font-bold text-foreground">
                    For grown-ups 👨‍👩‍👧
                  </h3>
                  <p className="text-foreground/75 text-sm md:text-base">
                    Resources, controls, and support for parents and caregivers.
                  </p>
                </div>
              </div>
              <Link to="/#parents">
                <Button variant="hero" size="lg">Open parent area</Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default ExplorePage;
