import { useState } from "react";
import SectionLayout from "@/components/section/SectionLayout";
import MoodEntry from "@/components/section/MoodEntry";
import ChoiceCard from "@/components/section/ChoiceCard";
import CompletionScreen from "@/components/section/CompletionScreen";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight, Pause } from "lucide-react";

type Vibe = "cozy" | "adventure" | "funny" | "sleepy";

const vibes: { id: Vibe; label: string; emoji: string; bg: string }[] = [
  { id: "cozy", label: "Cozy", emoji: "🧸", bg: "bg-accent" },
  { id: "adventure", label: "Adventure", emoji: "🗺️", bg: "bg-sunshine" },
  { id: "funny", label: "Funny", emoji: "😂", bg: "bg-secondary" },
  { id: "sleepy", label: "Sleepy", emoji: "🌙", bg: "bg-lavender" },
];

const stories: Record<Vibe, { title: string; emoji: string; pages: string[] }[]> = {
  cozy: [
    {
      title: "The Soft Blanket Fort",
      emoji: "🏕️",
      pages: [
        "Mira built a fort out of every soft thing she could find.",
        "Inside, the world felt smaller and kinder.",
        "She listened to the rain and felt her shoulders melt.",
        "Tomorrow could wait. Right now was perfect.",
      ],
    },
  ],
  adventure: [
    {
      title: "Leo and the Tiny Map",
      emoji: "🧭",
      pages: [
        "Leo found a tiny map under a leaf.",
        "It led to a tree he had walked past a hundred times.",
        "Behind the tree was a quiet pond, full of stars.",
        "Some adventures are small and shiny.",
      ],
    },
  ],
  funny: [
    {
      title: "The Cat Who Forgot to Cat",
      emoji: "🐱",
      pages: [
        "Pickles the cat woke up and forgot how to be a cat.",
        "She tried barking. It sounded like a sneeze.",
        "She tried hopping. She mostly fell over.",
        "Then she yawned and remembered. Cats are perfect at napping.",
      ],
    },
  ],
  sleepy: [
    {
      title: "Goodnight, Little Cloud",
      emoji: "☁️",
      pages: [
        "A little cloud was getting ready for bed.",
        "It floated past the moon and waved softly.",
        "It tucked itself behind a sleepy mountain.",
        "Goodnight, little cloud. Goodnight, you.",
      ],
    },
  ],
};

type Stage = "vibe" | "pick" | "read" | "checkin" | "done";

const Stories = () => {
  const [stage, setStage] = useState<Stage>("vibe");
  const [vibe, setVibe] = useState<Vibe | null>(null);
  const [storyIdx, setStoryIdx] = useState(0);
  const [page, setPage] = useState(0);

  const list = vibe ? stories[vibe] : [];
  const story = list[storyIdx];

  const reset = () => {
    setStage("vibe");
    setVibe(null);
    setStoryIdx(0);
    setPage(0);
  };

  return (
    <SectionLayout
      title="Stories"
      emoji="📖"
      tagline="Calm stories made just for you 💛"
      bgClass="bg-gradient-warm"
    >
      {stage === "vibe" && (
        <div className="space-y-8">
          <MoodEntry
            question="Pick a vibe"
            hint="What kind of story sounds good right now?"
            options={vibes}
            value={vibe}
            onChange={(v) => {
              setVibe(v);
              setStage("pick");
            }}
          />
        </div>
      )}

      {stage === "pick" && vibe && (
        <div className="space-y-6">
          <h2 className="font-[Fredoka] text-2xl md:text-3xl font-bold text-center">
            Stories for you
          </h2>
          <p className="text-center text-muted-foreground -mt-4">Reading time: 3–5 min</p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {list.map((s, i) => (
              <ChoiceCard
                key={s.title}
                emoji={s.emoji}
                title={s.title}
                desc="A gentle tale, just for now."
                bg="bg-card"
                iconBg="bg-accent"
                onClick={() => {
                  setStoryIdx(i);
                  setPage(0);
                  setStage("read");
                }}
              />
            ))}
          </div>
          <div className="text-center">
            <Button variant="ghost" size="sm" onClick={() => setStage("vibe")}>
              <ArrowLeft className="h-4 w-4" /> Pick a different vibe
            </Button>
          </div>
        </div>
      )}

      {stage === "read" && story && (
        <div className="max-w-2xl mx-auto">
          <div className="rounded-[2.5rem] bg-card p-8 md:p-12 shadow-soft min-h-[320px] flex flex-col">
            <div className="text-5xl mb-6 text-center" aria-hidden>{story.emoji}</div>
            <h2 className="font-[Fredoka] text-2xl md:text-3xl font-bold text-center mb-6">
              {story.title}
            </h2>
            <p className="text-xl md:text-2xl leading-relaxed text-foreground/85 text-center flex-1">
              {story.pages[page]}
            </p>
            <div className="mt-8 flex items-center justify-between">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setPage((p) => Math.max(0, p - 1))}
                disabled={page === 0}
              >
                <ArrowLeft className="h-4 w-4" /> Back
              </Button>
              <span className="text-sm text-muted-foreground">
                Page {page + 1} of {story.pages.length}
              </span>
              {page < story.pages.length - 1 ? (
                <Button
                  variant="hero"
                  size="sm"
                  onClick={() => {
                    const next = page + 1;
                    if (next === Math.floor(story.pages.length / 2)) {
                      setPage(next);
                      setStage("checkin");
                    } else {
                      setPage(next);
                    }
                  }}
                >
                  Turn page <ArrowRight className="h-4 w-4" />
                </Button>
              ) : (
                <Button variant="hero" size="sm" onClick={() => setStage("done")}>
                  Finish ✨
                </Button>
              )}
            </div>
          </div>
        </div>
      )}

      {stage === "checkin" && (
        <div className="max-w-md mx-auto text-center rounded-[2rem] bg-card p-8 shadow-soft animate-fade-up">
          <Pause className="h-10 w-10 text-primary mx-auto mb-3" />
          <h3 className="font-[Fredoka] text-2xl font-bold mb-2">Want to keep going?</h3>
          <p className="text-muted-foreground mb-6">No rush. You can come back later.</p>
          <div className="flex gap-3 justify-center flex-wrap">
            <Button variant="hero" onClick={() => setStage("read")}>Yes, keep reading</Button>
            <Button variant="outline" onClick={() => setStage("done")}>Take a break</Button>
          </div>
        </div>
      )}

      {stage === "done" && (
        <CompletionScreen
          emoji="🌟"
          title="You finished a story!"
          message="A sticker was added to your shelf. That was lovely reading."
          onRepeat={reset}
          repeatLabel="Read another"
        />
      )}
    </SectionLayout>
  );
};

export default Stories;
