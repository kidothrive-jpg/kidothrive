import { useEffect, useRef, useState } from "react";
import SectionLayout from "@/components/section/SectionLayout";
import MoodEntry from "@/components/section/MoodEntry";
import ChoiceCard from "@/components/section/ChoiceCard";
import CompletionScreen from "@/components/section/CompletionScreen";
import { Button } from "@/components/ui/button";
import { Play, Pause, ArrowLeft, Volume2 } from "lucide-react";

type Feeling = "sleepy" | "focused" | "happy" | "calm";
type Stage = "feeling" | "pick" | "play" | "done";

const feelings: { id: Feeling; label: string; emoji: string; bg: string }[] = [
  { id: "sleepy", label: "Sleepy", emoji: "🌙", bg: "bg-lavender" },
  { id: "focused", label: "Focused", emoji: "🎯", bg: "bg-secondary" },
  { id: "happy", label: "Happy", emoji: "😊", bg: "bg-sunshine" },
  { id: "calm", label: "Calm", emoji: "🌿", bg: "bg-accent" },
];

type Sound = {
  id: string;
  label: string;
  emoji: string;
  bg: string;
  feelings: Feeling[];
  // Web Audio synthesis params
  type: "noise" | "tone";
  freq?: number;
};

const sounds: Sound[] = [
  { id: "rain", label: "Rain", emoji: "🌧️", bg: "bg-secondary", feelings: ["sleepy", "calm", "focused"], type: "noise" },
  { id: "forest", label: "Forest", emoji: "🌲", bg: "bg-primary", feelings: ["calm", "focused"], type: "noise" },
  { id: "lofi", label: "Lo-fi", emoji: "🎧", bg: "bg-lavender", feelings: ["focused", "happy"], type: "tone", freq: 220 },
  { id: "hum", label: "Soft Hum", emoji: "🫧", bg: "bg-accent", feelings: ["sleepy", "calm"], type: "tone", freq: 110 },
];

const Sounds = () => {
  const [stage, setStage] = useState<Stage>("feeling");
  const [feeling, setFeeling] = useState<Feeling | null>(null);
  const [sound, setSound] = useState<Sound | null>(null);
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(0.4);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const nodesRef = useRef<{ stop: () => void } | null>(null);

  const filtered = feeling ? sounds.filter((s) => s.feelings.includes(feeling)) : sounds;

  const stopAudio = () => {
    nodesRef.current?.stop();
    nodesRef.current = null;
    setPlaying(false);
  };

  const startAudio = (s: Sound) => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    const ctx = audioCtxRef.current;
    const gain = ctx.createGain();
    // Soft volume cap
    gain.gain.value = Math.min(volume, 0.6);
    gain.connect(ctx.destination);

    if (s.type === "noise") {
      const buffer = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * 0.5;
      const src = ctx.createBufferSource();
      src.buffer = buffer;
      src.loop = true;
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = s.id === "forest" ? 600 : 1200;
      src.connect(filter);
      filter.connect(gain);
      src.start();
      nodesRef.current = {
        stop: () => {
          src.stop();
          gain.disconnect();
        },
      };
    } else {
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      osc1.type = "sine";
      osc2.type = "sine";
      osc1.frequency.value = s.freq || 220;
      osc2.frequency.value = (s.freq || 220) * 1.5;
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 800;
      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(gain);
      osc1.start();
      osc2.start();
      nodesRef.current = {
        stop: () => {
          osc1.stop();
          osc2.stop();
          gain.disconnect();
        },
      };
    }
    setPlaying(true);
  };

  useEffect(() => {
    return () => stopAudio();
  }, []);

  useEffect(() => {
    if (audioCtxRef.current && nodesRef.current) {
      // restart with new volume on change
      if (sound && playing) {
        stopAudio();
        startAudio(sound);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [volume]);

  const reset = () => {
    stopAudio();
    setStage("feeling");
    setFeeling(null);
    setSound(null);
  };

  return (
    <SectionLayout title="Sounds & Music" emoji="🎵" tagline="Soothing sounds and happy tunes 🎶" bgClass="bg-gradient-sky">
      {stage === "feeling" && (
        <MoodEntry
          question="Pick a feeling"
          hint="Sounds will be matched to it."
          options={feelings}
          value={feeling}
          onChange={(f) => {
            setFeeling(f);
            setStage("pick");
          }}
        />
      )}

      {stage === "pick" && (
        <div className="space-y-6 max-w-3xl mx-auto">
          <h2 className="font-[Fredoka] text-2xl md:text-3xl font-bold text-center">
            Pick a sound
          </h2>
          <div className="grid sm:grid-cols-2 gap-6">
            {filtered.map((s) => (
              <ChoiceCard
                key={s.id}
                emoji={s.emoji}
                title={s.label}
                desc="Soft and steady."
                bg={`${s.bg}/40`}
                iconBg={s.bg}
                onClick={() => {
                  setSound(s);
                  setStage("play");
                }}
              />
            ))}
          </div>
          <div className="text-center">
            <Button variant="ghost" size="sm" onClick={() => setStage("feeling")}>
              <ArrowLeft className="h-4 w-4" /> Pick a different feeling
            </Button>
          </div>
        </div>
      )}

      {stage === "play" && sound && (
        <div className="max-w-xl mx-auto text-center">
          <div className="rounded-[2.5rem] bg-card p-10 shadow-soft">
            <p className="text-muted-foreground mb-4">Now playing</p>
            <div className="text-6xl mb-4" aria-hidden>{sound.emoji}</div>
            <h3 className="font-[Fredoka] text-3xl font-bold mb-6">{sound.label}</h3>

            <div className="flex justify-center mb-6">
              <div
                className={`h-40 w-40 rounded-full bg-gradient-rainbow shadow-glow ${
                  playing ? "animate-blob" : ""
                }`}
                aria-hidden
              />
            </div>

            <div className="flex items-center justify-center gap-3 mb-4">
              {playing ? (
                <Button variant="hero" size="lg" onClick={stopAudio}>
                  <Pause className="h-5 w-5" /> Pause
                </Button>
              ) : (
                <Button variant="hero" size="lg" onClick={() => startAudio(sound)}>
                  <Play className="h-5 w-5" /> Play
                </Button>
              )}
            </div>

            <div className="flex items-center gap-3 max-w-xs mx-auto">
              <Volume2 className="h-4 w-4 text-muted-foreground" />
              <input
                type="range"
                min={0}
                max={0.6}
                step={0.05}
                value={volume}
                onChange={(e) => setVolume(Number(e.target.value))}
                aria-label="Volume"
                className="w-full accent-primary"
              />
            </div>
            <p className="text-xs text-muted-foreground mt-2">Volume is gently capped 🌿</p>

            <div className="mt-6 flex gap-2 justify-center">
              <Button variant="outline" size="sm" onClick={() => setStage("pick")}>
                <ArrowLeft className="h-4 w-4" /> Pick another
              </Button>
              <Button variant="outline" size="sm" onClick={() => { stopAudio(); setStage("done"); }}>
                I'm done listening
              </Button>
            </div>
          </div>
        </div>
      )}

      {stage === "done" && (
        <CompletionScreen
          emoji="🎶"
          title="Thanks for listening."
          message="Your ears had a soft little break. Come back anytime."
          onRepeat={reset}
          repeatLabel="Listen again"
        />
      )}
    </SectionLayout>
  );
};

export default Sounds;
