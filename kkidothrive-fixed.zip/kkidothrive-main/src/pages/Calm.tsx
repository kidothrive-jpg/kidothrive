import { useEffect, useRef, useState } from "react";
import SectionLayout from "@/components/section/SectionLayout";
import MoodEntry from "@/components/section/MoodEntry";
import ChoiceCard from "@/components/section/ChoiceCard";
import CompletionScreen from "@/components/section/CompletionScreen";
import { Button } from "@/components/ui/button";
import { Wind, Hand, Eye, Sparkles, ArrowLeft } from "lucide-react";

type Size = "tiny" | "medium" | "big";
type Tool = "breathe" | "stretch" | "visualize" | "tap";
type Stage = "size" | "pick" | "guide" | "checkin" | "done";

const sizes: { id: Size; label: string; emoji: string; bg: string }[] = [
  { id: "tiny", label: "Tiny", emoji: "🌱", bg: "bg-secondary" },
  { id: "medium", label: "Medium", emoji: "🌼", bg: "bg-sunshine" },
  { id: "big", label: "Big", emoji: "🌊", bg: "bg-lavender" },
];

const tools: { id: Tool; label: string; emoji: string; desc: string; icon: any; bg: string }[] = [
  { id: "breathe", label: "Breathing", emoji: "🌬️", desc: "Slow breaths with the bubble.", icon: Wind, bg: "bg-secondary" },
  { id: "stretch", label: "Stretch", emoji: "🤸", desc: "Wiggle and reach.", icon: Hand, bg: "bg-sunshine" },
  { id: "visualize", label: "Visualize", emoji: "✨", desc: "Picture a calm place.", icon: Sparkles, bg: "bg-lavender" },
  { id: "tap", label: "Tap", emoji: "👆", desc: "Tap a soft beat.", icon: Eye, bg: "bg-accent" },
];

const Calm = () => {
  const [stage, setStage] = useState<Stage>("size");
  const [size, setSize] = useState<Size | null>(null);
  const [tool, setTool] = useState<Tool | null>(null);
  const [phase, setPhase] = useState<"in" | "hold" | "out">("in");
  const [secondsLeft, setSecondsLeft] = useState(120);
  const tickRef = useRef<number | null>(null);

  useEffect(() => {
    if (stage !== "guide") return;
    setSecondsLeft(120);
    setPhase("in");
    const breathOrder: ("in" | "hold" | "out")[] = ["in", "hold", "out"];
    const breathDur = [4000, 2000, 6000];
    let idx = 0;
    const cycle = () => {
      setPhase(breathOrder[idx]);
      const dur = breathDur[idx];
      idx = (idx + 1) % 3;
      tickRef.current = window.setTimeout(cycle, dur);
    };
    cycle();

    const sec = window.setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          window.clearInterval(sec);
          setStage("checkin");
          return 0;
        }
        return s - 1;
      });
    }, 1000);

    return () => {
      if (tickRef.current) window.clearTimeout(tickRef.current);
      window.clearInterval(sec);
    };
  }, [stage]);

  const reset = () => {
    setStage("size");
    setSize(null);
    setTool(null);
  };

  const phaseLabel = phase === "in" ? "Breathe in…" : phase === "hold" ? "Hold gently…" : "Breathe out…";

  return (
    <SectionLayout title="Calm Corner" emoji="🧘" tagline="Relax, breathe, and reset 🌿" bgClass="bg-gradient-sky">
      {stage === "size" && (
        <MoodEntry
          question="How big is the feeling?"
          hint="There's no wrong answer."
          options={sizes}
          value={size}
          onChange={(s) => {
            setSize(s);
            setStage("pick");
          }}
        />
      )}

      {stage === "pick" && (
        <div className="space-y-6 max-w-3xl mx-auto">
          <h2 className="font-[Fredoka] text-2xl md:text-3xl font-bold text-center">
            Pick a calm tool
          </h2>
          <div className="grid sm:grid-cols-2 gap-6">
            {tools.map((t) => (
              <ChoiceCard
                key={t.id}
                icon={t.icon}
                emoji={t.emoji}
                title={t.label}
                desc={t.desc}
                bg={`${t.bg}/40`}
                iconBg={t.bg}
                onClick={() => {
                  setTool(t.id);
                  setStage("guide");
                }}
              />
            ))}
          </div>
          <div className="text-center">
            <Button variant="ghost" size="sm" onClick={() => setStage("size")}>
              <ArrowLeft className="h-4 w-4" /> Back
            </Button>
          </div>
        </div>
      )}

      {stage === "guide" && (
        <div className="max-w-xl mx-auto text-center">
          <div className="rounded-[2.5rem] bg-card p-10 shadow-soft">
            <p className="text-muted-foreground mb-6">2 minutes • Stop anytime</p>
            <div className="relative h-64 flex items-center justify-center">
              <div
                className="rounded-full bg-gradient-rainbow shadow-glow transition-all"
                style={{
                  width: phase === "in" ? 220 : phase === "hold" ? 220 : 110,
                  height: phase === "in" ? 220 : phase === "hold" ? 220 : 110,
                  transitionDuration: phase === "in" ? "4000ms" : phase === "out" ? "6000ms" : "2000ms",
                  transitionTimingFunction: "ease-in-out",
                }}
                aria-hidden
              />
            </div>
            <h3 className="font-[Fredoka] text-2xl md:text-3xl font-bold mt-6">{phaseLabel}</h3>
            <p className="text-sm text-muted-foreground mt-2">
              {Math.floor(secondsLeft / 60)}:{String(secondsLeft % 60).padStart(2, "0")} left
            </p>
            <div className="mt-6">
              <Button variant="outline" size="sm" onClick={() => setStage("checkin")}>
                I feel done
              </Button>
            </div>
          </div>
        </div>
      )}

      {stage === "checkin" && (
        <div className="max-w-md mx-auto text-center rounded-[2rem] bg-card p-8 shadow-soft animate-fade-up">
          <h3 className="font-[Fredoka] text-2xl font-bold mb-2">How do you feel now?</h3>
          <p className="text-muted-foreground mb-6">Whatever you feel is okay.</p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Button variant="outline" onClick={() => setStage("done")}>Same 💭</Button>
            <Button variant="sunshine" onClick={() => setStage("done")}>A little better 🌤️</Button>
            <Button variant="hero" onClick={() => setStage("done")}>Better ☀️</Button>
          </div>
        </div>
      )}

      {stage === "done" && (
        <CompletionScreen
          emoji="🌿"
          title="You took care of yourself."
          message="That's brave. Come back anytime your feelings need company."
          onRepeat={reset}
          repeatLabel="Try another tool"
        />
      )}
    </SectionLayout>
  );
};

export default Calm;
