import { useEffect, useMemo, useState } from "react";
import SectionLayout from "@/components/section/SectionLayout";
import MoodEntry from "@/components/section/MoodEntry";
import ChoiceCard from "@/components/section/ChoiceCard";
import CompletionScreen from "@/components/section/CompletionScreen";
import { Button } from "@/components/ui/button";
import { Lightbulb, Puzzle, Eye, Brain, Layers, ArrowLeft } from "lucide-react";

type GameType = "match" | "spot" | "patterns" | "memory";
type Difficulty = "easy" | "just-right" | "challenge";
type Stage = "mood" | "pick" | "play" | "done";

const games: { id: GameType; label: string; emoji: string; icon: any; bg: string }[] = [
  { id: "match", label: "Match", emoji: "🧩", icon: Puzzle, bg: "bg-accent/40" },
  { id: "spot", label: "Spot it", emoji: "👀", icon: Eye, bg: "bg-sunshine/50" },
  { id: "patterns", label: "Patterns", emoji: "🔵", icon: Layers, bg: "bg-secondary/60" },
  { id: "memory", label: "Memory", emoji: "🧠", icon: Brain, bg: "bg-lavender/60" },
];

const difficulties: { id: Difficulty; label: string; emoji: string; bg: string }[] = [
  { id: "easy", label: "Easy", emoji: "🌱", bg: "bg-secondary" },
  { id: "just-right", label: "Just right", emoji: "🌼", bg: "bg-sunshine" },
  { id: "challenge", label: "Challenge me", emoji: "🚀", bg: "bg-accent" },
];

const PALETTE = ["🍎", "🍌", "🍇", "🍊", "🍓", "🥝", "🍑", "🍋"];

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const Games = () => {
  const [stage, setStage] = useState<Stage>("mood");
  const [game, setGame] = useState<GameType | null>(null);
  const [difficulty, setDifficulty] = useState<Difficulty | null>(null);
  const [round, setRound] = useState(0);
  const [hintShown, setHintShown] = useState(false);

  // Match game state
  const pairCount = difficulty === "easy" ? 3 : difficulty === "challenge" ? 6 : 4;
  const [target, setTarget] = useState<string>("🍎");
  const [options, setOptions] = useState<string[]>([]);
  const [picked, setPicked] = useState<string | null>(null);

  const newRound = useMemo(
    () => () => {
      const pool = shuffle(PALETTE).slice(0, pairCount);
      const t = pool[Math.floor(Math.random() * pool.length)];
      setTarget(t);
      setOptions(shuffle(pool));
      setPicked(null);
      setHintShown(false);
    },
    [pairCount]
  );

  useEffect(() => {
    if (stage === "play") newRound();
  }, [stage, round, newRound]);

  const onPick = (v: string) => {
    setPicked(v);
    if (v === target) {
      setTimeout(() => setRound((r) => r + 1), 700);
    }
  };

  const reset = () => {
    setStage("mood");
    setGame(null);
    setDifficulty(null);
    setRound(0);
  };

  return (
    <SectionLayout title="Games" emoji="🎮" tagline="Fun and gentle brain games 🧠" bgClass="bg-gradient-sky">
      {stage === "mood" && (
        <MoodEntry
          question="Pick a brain mood"
          hint="What feels good for your brain today?"
          options={games.map((g) => ({ id: g.id, label: g.label, emoji: g.emoji, bg: g.bg }))}
          value={game}
          onChange={(g) => {
            setGame(g);
            setStage("pick");
          }}
        />
      )}

      {stage === "pick" && (
        <div className="space-y-6 max-w-3xl mx-auto">
          <h2 className="font-[Fredoka] text-2xl md:text-3xl font-bold text-center">
            How tricky should it be?
          </h2>
          <div className="grid sm:grid-cols-3 gap-6">
            {difficulties.map((d) => (
              <ChoiceCard
                key={d.id}
                emoji={d.emoji}
                title={d.label}
                desc={d.id === "easy" ? "Slow and steady." : d.id === "challenge" ? "Stretch your brain." : "Right in the middle."}
                bg={`${d.bg}/40`}
                iconBg={d.bg}
                onClick={() => {
                  setDifficulty(d.id);
                  setStage("play");
                }}
              />
            ))}
          </div>
          <div className="text-center">
            <Button variant="ghost" size="sm" onClick={() => setStage("mood")}>
              <ArrowLeft className="h-4 w-4" /> Pick a different game
            </Button>
          </div>
        </div>
      )}

      {stage === "play" && (
        <div className="max-w-xl mx-auto">
          <div className="rounded-[2.5rem] bg-card p-8 md:p-10 shadow-soft text-center">
            <p className="text-sm text-muted-foreground mb-2">Round {round + 1} • No timer, no score</p>
            <h3 className="font-[Fredoka] text-2xl font-bold mb-6">Find this one</h3>
            <div className="text-7xl md:text-8xl mb-8 inline-block animate-float" aria-label={`Target ${target}`}>
              {target}
            </div>

            <div className={`grid gap-4 ${pairCount <= 4 ? "grid-cols-2" : "grid-cols-3"}`}>
              {options.map((o, i) => {
                const isPickedRight = picked === o && o === target;
                const isPickedWrong = picked === o && o !== target;
                const highlight = hintShown && o === target;
                return (
                  <button
                    key={`${o}-${i}`}
                    onClick={() => onPick(o)}
                    className={`aspect-square rounded-2xl text-5xl md:text-6xl shadow-soft transition-bounce hover:scale-105 flex items-center justify-center ${
                      isPickedRight
                        ? "bg-primary/40 ring-4 ring-primary"
                        : isPickedWrong
                        ? "bg-card opacity-70"
                        : highlight
                        ? "bg-sunshine/60 ring-4 ring-sunshine animate-wiggle"
                        : "bg-card hover:bg-accent/20"
                    }`}
                    aria-label={o}
                  >
                    {o}
                  </button>
                );
              })}
            </div>

            <div className="mt-8 flex items-center justify-between gap-3 flex-wrap">
              <Button variant="outline" size="sm" onClick={() => setHintShown(true)}>
                <Lightbulb className="h-4 w-4" /> Show a hint
              </Button>
              <p className="text-sm text-foreground/70 flex-1 text-center min-w-[160px]">
                {picked === target
                  ? "Nice thinking! ✨"
                  : picked
                  ? "Good try — pick again 💛"
                  : "You've got this."}
              </p>
              <Button variant="hero" size="sm" onClick={() => setStage("done")}>
                I'm done playing
              </Button>
            </div>
          </div>
        </div>
      )}

      {stage === "done" && (
        <CompletionScreen
          emoji="🧠"
          title="Nice thinking!"
          message="Your brain did a great job. Want to play another round?"
          onRepeat={reset}
          repeatLabel="Play again"
        />
      )}
    </SectionLayout>
  );
};

export default Games;
