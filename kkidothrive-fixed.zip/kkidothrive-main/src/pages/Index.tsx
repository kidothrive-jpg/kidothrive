import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Superpowers from "@/components/Superpowers";
import Explore from "@/components/Explore";
import ParentsCTA from "@/components/ParentsCTA";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <Hero />
        <Superpowers />
        <Explore />
        <ParentsCTA />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
