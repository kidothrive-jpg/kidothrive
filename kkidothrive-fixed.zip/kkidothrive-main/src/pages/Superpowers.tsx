import { useState } from "react";
import SectionLayout from "@/components/section/SectionLayout";
import ChoiceCard from "@/components/section/ChoiceCard";
import CompletionScreen from "@/components/section/CompletionScreen";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

type Stage = "entry" | "quiz" | "result" | "done";

type Power = {
  id: string;
  emoji: string;
  title: string;
  desc: string;
  bg: string;
};

const powers: Power[] = [
  { id: "pattern", emoji: "🧩", title: "Pattern Detective", desc: "You spot what others miss.", bg: "bg-accent" },
  { id: "feeler", emoji: "💛", title: "Deep Feeler", desc: "Your big heart is a gift.", bg: "bg-lavender" },
  { id: "mover", emoji: "⚡", title: "Big Mover", desc: "Your energy lights up rooms.", bg: "bg-sunshine" },
  { id: "dreamer", emoji: "🌙", title: "Dreamer", desc: "Your imagination has no edges.", bg: "bg-secondary" },
];

const questions: { q: string; options: { label: string; emoji: string; power: string }[] }[] = [
  {
    q: "When you find a new game, what do you do first?",
    options: [
      { label: "Look for the rules", emoji: "🧩", power: "pattern" },
      { label: "See how everyone feels", emoji: "💛", power: "feeler" },
      { label: "Try every button", emoji: "⚡", power: "mover" },
      { label: "Imagine a story for it", emoji: "🌙", power: "dreamer" },
    ],
  },
  {
    q: "Your favorite kind of day is…",
    options: [
      { label: "Building something tricky", emoji: "🧩", power: "pattern" },
      { label: "Time with someone you love", emoji: "💛", power: "feeler" },
      { label: "Running outside", emoji: "⚡", power: "mover" },
      { label: "Daydreaming on the floor", emoji: "🌙", power: "dreamer" },
    ],
  },
  {
    q: "Pick a tiny treasure",
    options: [
      { label: "A rock with a perfect spiral", emoji: "🧩", power: "pattern" },
      { label: "A note from a friend", emoji: "💛", power: "feeler" },
      { label: "A bouncy ball", emoji: "⚡", power: "mover" },
      { label: "A glittery sticker", emoji: "🌙", power: "dreamer" },
    ],
  },
];

const Superpowers = () => {
  const [stage, setStage] = useState<Stage>("entry");
  const [step, setStep] = useState(0);
  const [scores, setScores] = useState<Record<string, number>>({});
  const [result, setResult] = useState<Power | null>(null);

  const pickAnswer = (powerId: string) => {
    const next = { ...scores, [powerId]: (scores[powerId] || 0) + 1 };
    setScores(next);
    if (step + 1 < questions.length) {
      setStep(step + 1);
    } else {
      const top = Object.entries(next).sort((a, b) => b[1] - a[1])[0]?.[0];
      setResult(powers.find((p) => p.id === top) || powers[0]);
      setStage("result");
    }
  };

  const reset = () => {
    setStage("entry");
    setStep(0);
    setScores({});
    setResult(null);
  };

  return (
    <SectionLayout title="Superpowers" emoji="🌟" tagline="Discover what makes you amazing ✨" bgClass="bg-gradient-warm">
      {stage === "entry" && (
        <div className="space-y-8 max-w-3xl mx-auto">
          <div className="text-center">
            <h2 className="font-[Fredoka] text-2xl md:text-3xl font-bold">
              Want to discover or revisit?
            </h2>
            <p className="text-muted-foreground mt-1">No wrong answers. Ever.</p>
          </div>
          <div className="grid sm:grid-cols-2 gap-6">
            <ChoiceCard
              emoji="🔍"
              title="New quiz"
              desc="Find your power for today."
              bg="bg-accent/40"
              iconBg="bg-accent"
              onClick={() => setStage("quiz")}
            />
            <ChoiceCard
              emoji="📚"
              title="My powers"
              desc="See what makes you amazing."
              bg="bg-lavender/40"
              iconBg="bg-lavender"
              onClick={() => {
                setResult(powers[1]);
                setStage("result");
              }}
            />
          </div>

          <div>
            <h3 className="font-[Fredoka] text-xl font-bold text-center mb-4">All the powers</h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {powers.map((p) => (
                <div key={p.id} className={`${p.bg}/40 rounded-[1.5rem] p-5 text-center shadow-soft`}>
                  <div className="text-4xl mb-2">{p.emoji}</div>
                  <p className="font-[Fredoka] font-bold">{p.title}</p>
                  <p className="text-xs text-foreground/70 mt-1">{p.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {stage === "quiz" && (
        <div className="max-w-2xl mx-auto">
          <div className="rounded-[2.5rem] bg-card p-8 md:p-10 shadow-soft">
            <p className="text-sm text-muted-foreground mb-2 text-center">
              Question {step + 1} of {questions.length}
            </p>
            <h3 className="font-[Fredoka] text-2xl md:text-3xl font-bold mb-6 text-center">
              {questions[step].q}
            </h3>
            <div className="grid sm:grid-cols-2 gap-4">
              {questions[step].options.map((o) => (
                <button
                  key={o.label}
                  onClick={() => pickAnswer(o.power)}
                  className="rounded-2xl bg-muted/60 hover:bg-accent/30 p-5 shadow-soft transition-bounce hover:scale-[1.02] text-left flex items-center gap-3"
                >
                  <span className="text-3xl" aria-hidden>{o.emoji}</span>
                  <span className="font-semibold text-foreground">{o.label}</span>
                </button>
              ))}
            </div>
            <div className="text-center mt-6">
              <Button variant="ghost" size="sm" onClick={() => setStage("entry")}>
                <ArrowLeft className="h-4 w-4" /> Stop quiz
              </Button>
            </div>
          </div>
        </div>
      )}

      {stage === "result" && result && (
        <div className="max-w-xl mx-auto text-center">
          <div className={`rounded-[2.5rem] ${result.bg}/50 p-10 shadow-soft animate-fade-up`}>
            <p className="text-muted-foreground">Your power today is…</p>
            <div className="text-7xl my-4 inline-block animate-wiggle" aria-hidden>{result.emoji}</div>
            <h2 className="font-[Fredoka] text-3xl md:text-4xl font-bold">{result.title}</h2>
            <p className="text-lg text-foreground/80 mt-3">{result.desc}</p>
            <p className="text-sm text-muted-foreground mt-4">Saved to your power collection 💫</p>
            <div className="mt-6 flex gap-3 justify-center flex-wrap">
              <Button variant="hero" onClick={() => setStage("done")}>Finish</Button>
              <Button variant="outline" onClick={reset}>Try again</Button>
            </div>
          </div>
        </div>
      )}

      {stage === "done" && (
        <CompletionScreen
          emoji="🌟"
          title="You are amazing."
          message="Every power on this list is part of you. Come back anytime."
          onRepeat={reset}
          repeatLabel="Discover another"
        />
      )}
    </SectionLayout>
  );
};

export default Superpowers;
