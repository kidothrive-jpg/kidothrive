import { useEffect, useRef, useState } from "react";
import SectionLayout from "@/components/section/SectionLayout";
import ChoiceCard from "@/components/section/ChoiceCard";
import CompletionScreen from "@/components/section/CompletionScreen";
import { Button } from "@/components/ui/button";
import { Brush, Eraser, Undo2, Save, ArrowLeft } from "lucide-react";

type Activity = "draw" | "color" | "build" | "story";
type Stage = "pick" | "make" | "done";

const activities: { id: Activity; label: string; emoji: string; desc: string; bg: string }[] = [
  { id: "draw", label: "Draw", emoji: "✏️", desc: "Blank canvas, just for you.", bg: "bg-accent" },
  { id: "color", label: "Color", emoji: "🎨", desc: "Fill in something gentle.", bg: "bg-sunshine" },
  { id: "build", label: "Build", emoji: "🧱", desc: "Stack shapes into something new.", bg: "bg-secondary" },
  { id: "story", label: "Story", emoji: "✨", desc: "Pick prompts to make a tale.", bg: "bg-lavender" },
];

const COLORS = [
  "hsl(18 90% 70%)",
  "hsl(45 95% 65%)",
  "hsl(145 45% 55%)",
  "hsl(200 75% 65%)",
  "hsl(265 60% 70%)",
  "hsl(220 35% 30%)",
];

const Create = () => {
  const [stage, setStage] = useState<Stage>("pick");
  const [activity, setActivity] = useState<Activity | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [color, setColor] = useState(COLORS[0]);
  const [size, setSize] = useState(10);
  const [erasing, setErasing] = useState(false);
  const drawing = useRef(false);
  const last = useRef<{ x: number; y: number } | null>(null);
  const history = useRef<ImageData[]>([]);

  useEffect(() => {
    if (stage !== "make") return;
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = c.getBoundingClientRect();
    c.width = rect.width * dpr;
    c.height = rect.height * dpr;
    ctx.scale(dpr, dpr);
    ctx.fillStyle = "hsl(42 60% 99%)";
    ctx.fillRect(0, 0, rect.width, rect.height);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    history.current = [ctx.getImageData(0, 0, c.width, c.height)];
  }, [stage]);

  const pos = (e: React.PointerEvent) => {
    const c = canvasRef.current!;
    const r = c.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };

  const start = (e: React.PointerEvent) => {
    drawing.current = true;
    last.current = pos(e);
    (e.target as Element).setPointerCapture(e.pointerId);
  };

  const move = (e: React.PointerEvent) => {
    if (!drawing.current || !last.current) return;
    const ctx = canvasRef.current!.getContext("2d")!;
    const p = pos(e);
    ctx.strokeStyle = erasing ? "hsl(42 60% 99%)" : color;
    ctx.lineWidth = erasing ? size * 2.5 : size;
    ctx.beginPath();
    ctx.moveTo(last.current.x, last.current.y);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    last.current = p;
  };

  const end = () => {
    if (!drawing.current) return;
    drawing.current = false;
    last.current = null;
    const c = canvasRef.current!;
    const ctx = c.getContext("2d")!;
    history.current.push(ctx.getImageData(0, 0, c.width, c.height));
    if (history.current.length > 30) history.current.shift();
  };

  const undo = () => {
    if (history.current.length <= 1) return;
    history.current.pop();
    const ctx = canvasRef.current!.getContext("2d")!;
    ctx.putImageData(history.current[history.current.length - 1], 0, 0);
  };

  const save = () => {
    const c = canvasRef.current;
    if (c) {
      const link = document.createElement("a");
      link.download = "kidothrive-creation.png";
      link.href = c.toDataURL("image/png");
      link.click();
    }
    setStage("done");
  };

  const reset = () => {
    setStage("pick");
    setActivity(null);
  };

  return (
    <SectionLayout title="Create" emoji="🎨" tagline="Draw, imagine, and express yourself ✨" bgClass="bg-gradient-warm">
      {stage === "pick" && (
        <div className="max-w-3xl mx-auto space-y-6">
          <h2 className="font-[Fredoka] text-2xl md:text-3xl font-bold text-center">
            What to make today?
          </h2>
          <div className="grid sm:grid-cols-2 gap-6">
            {activities.map((a) => (
              <ChoiceCard
                key={a.id}
                emoji={a.emoji}
                title={a.label}
                desc={a.desc}
                bg={`${a.bg}/40`}
                iconBg={a.bg}
                onClick={() => {
                  setActivity(a.id);
                  setStage("make");
                }}
              />
            ))}
          </div>
        </div>
      )}

      {stage === "make" && (
        <div className="max-w-4xl mx-auto space-y-4">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <Button variant="ghost" size="sm" onClick={() => setStage("pick")}>
              <ArrowLeft className="h-4 w-4" /> Pick something else
            </Button>
            <p className="text-sm text-muted-foreground">Auto-saving as you go ✨</p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={undo}>
                <Undo2 className="h-4 w-4" /> Undo
              </Button>
              <Button variant="hero" size="sm" onClick={save}>
                <Save className="h-4 w-4" /> Save
              </Button>
            </div>
          </div>

          <div className="rounded-[2rem] bg-card p-3 shadow-soft">
            <canvas
              ref={canvasRef}
              onPointerDown={start}
              onPointerMove={move}
              onPointerUp={end}
              onPointerCancel={end}
              className="w-full h-[420px] md:h-[500px] rounded-[1.5rem] touch-none cursor-crosshair"
              style={{ background: "hsl(42 60% 99%)" }}
            />
          </div>

          <div className="rounded-[2rem] bg-card p-4 shadow-soft flex flex-wrap items-center justify-center gap-4">
            <div className="flex items-center gap-2">
              {COLORS.map((c) => (
                <button
                  key={c}
                  onClick={() => {
                    setColor(c);
                    setErasing(false);
                  }}
                  aria-label={`Color ${c}`}
                  className={`h-9 w-9 rounded-full shadow-soft transition-bounce hover:scale-110 ${
                    color === c && !erasing ? "ring-4 ring-foreground/30 scale-110" : ""
                  }`}
                  style={{ background: c }}
                />
              ))}
            </div>
            <div className="flex items-center gap-2">
              <Brush className="h-4 w-4 text-muted-foreground" />
              <input
                type="range"
                min={4}
                max={30}
                value={size}
                onChange={(e) => setSize(Number(e.target.value))}
                aria-label="Brush size"
                className="accent-primary"
              />
            </div>
            <Button
              variant={erasing ? "hero" : "outline"}
              size="sm"
              onClick={() => setErasing((v) => !v)}
            >
              <Eraser className="h-4 w-4" /> Eraser
            </Button>
          </div>
        </div>
      )}

      {stage === "done" && (
        <CompletionScreen
          emoji="🖼️"
          title="Look what you made!"
          message="Saved to your gallery. Want to share with a grown-up?"
          onRepeat={reset}
          repeatLabel="Make another"
        />
      )}
    </SectionLayout>
  );
};

export default Create;
